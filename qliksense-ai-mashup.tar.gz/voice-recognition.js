/**
 * Voice Recognition Service
 * Handles speech-to-text functionality using Web Speech API
 */

const VoiceRecognition = {
    recognition: null,
    isListening: false,
    isSupported: false,
    language: 'en-US',
    interimResults: true,
    maxAlternatives: 1,

    /**
     * Initialize voice recognition
     */
    init() {
        console.log('Initializing Voice Recognition...');
        this.checkSupport();
        this.setupRecognition();
        this.setupEventHandlers();
    },

    /**
     * Check if speech recognition is supported
     */
    checkSupport() {
        // Check for Web Speech API support
        this.isSupported = 'webkitSpeechRecognition' in window || 'SpeechRecognition' in window;
        
        if (!this.isSupported) {
            console.warn('Speech recognition not supported in this browser');
            this.disableVoiceButton();
            return;
        }

        console.log('Speech recognition is supported');
    },

    /**
     * Setup speech recognition instance
     */
    setupRecognition() {
        if (!this.isSupported) return;

        // Create speech recognition instance
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        this.recognition = new SpeechRecognition();

        // Configure recognition settings
        this.recognition.continuous = false;
        this.recognition.interimResults = this.interimResults;
        this.recognition.lang = this.language;
        this.recognition.maxAlternatives = this.maxAlternatives;

        // Setup recognition event handlers
        this.setupRecognitionHandlers();
    },

    /**
     * Setup speech recognition event handlers
     */
    setupRecognitionHandlers() {
        if (!this.recognition) return;

        // Recognition start
        this.recognition.onstart = () => {
            console.log('Speech recognition started');
            this.onRecognitionStart();
        };

        // Recognition result
        this.recognition.onresult = (event) => {
            console.log('Speech recognition result received');
            this.onRecognitionResult(event);
        };

        // Recognition error
        this.recognition.onerror = (event) => {
            console.error('Speech recognition error:', event.error);
            this.onRecognitionError(event);
        };

        // Recognition end
        this.recognition.onend = () => {
            console.log('Speech recognition ended');
            this.onRecognitionEnd();
        };

        // No speech detected
        this.recognition.onspeechend = () => {
            console.log('Speech ended');
        };

        // Sound detection start
        this.recognition.onsoundstart = () => {
            console.log('Sound detection started');
        };

        // Sound detection end
        this.recognition.onsoundend = () => {
            console.log('Sound detection ended');
        };
    },

    /**
     * Setup UI event handlers
     */
    setupEventHandlers() {
        // Voice button click
        $('#voice-btn').on('click', () => {
            this.toggleListening();
        });

        // Keyboard shortcut (Ctrl+Shift+V)
        $(document).on('keydown', (e) => {
            if (e.ctrlKey && e.shiftKey && e.key === 'V') {
                e.preventDefault();
                this.toggleListening();
            }
        });
    },

    /**
     * Toggle voice listening
     */
    toggleListening() {
        if (!this.isSupported) {
            this.showUnsupportedMessage();
            return;
        }

        if (this.isListening) {
            this.stopListening();
        } else {
            this.startListening();
        }
    },

    /**
     * Start voice recognition
     */
    startListening() {
        if (!this.recognition || this.isListening) return;

        try {
            this.recognition.start();
            this.isListening = true;
        } catch (error) {
            console.error('Failed to start speech recognition:', error);
            this.showErrorMessage('Failed to start voice recognition. Please try again.');
        }
    },

    /**
     * Stop voice recognition
     */
    stopListening() {
        if (!this.recognition || !this.isListening) return;

        try {
            this.recognition.stop();
            this.isListening = false;
        } catch (error) {
            console.error('Failed to stop speech recognition:', error);
        }
    },

    /**
     * Handle recognition start
     */
    onRecognitionStart() {
        this.isListening = true;
        this.updateVoiceButton(true);
        this.updateInputStatus('Listening... Speak now');
        
        // Visual feedback
        $('#voice-btn').addClass('active');
    },

    /**
     * Handle recognition result
     */
    onRecognitionResult(event) {
        let finalTranscript = '';
        let interimTranscript = '';

        // Process results
        for (let i = event.resultIndex; i < event.results.length; i++) {
            const transcript = event.results[i][0].transcript;
            
            if (event.results[i].isFinal) {
                finalTranscript += transcript;
            } else {
                interimTranscript += transcript;
            }
        }

        // Update input field
        const currentValue = $('#message-input').val();
        
        if (finalTranscript) {
            // Final result - append to input
            const newValue = currentValue + finalTranscript;
            $('#message-input').val(newValue.trim());
            
            this.updateInputStatus(`Recognized: "${finalTranscript.trim()}"`);
            
            // Auto-send if preference is set (optional)
            if (this.shouldAutoSend(finalTranscript)) {
                setTimeout(() => {
                    if (window.Chatbot) {
                        Chatbot.sendMessage();
                    }
                }, 500);
            }
        } else if (interimTranscript) {
            // Interim result - show preview
            this.updateInputStatus(`Recognizing: "${interimTranscript.trim()}"`);
        }
    },

    /**
     * Handle recognition error
     */
    onRecognitionError(event) {
        console.error('Speech recognition error:', event.error);
        
        let errorMessage = 'Voice recognition error: ';
        
        switch (event.error) {
            case 'no-speech':
                errorMessage += 'No speech detected. Please try again.';
                break;
            case 'audio-capture':
                errorMessage += 'Microphone access denied or unavailable.';
                break;
            case 'not-allowed':
                errorMessage += 'Microphone permission denied. Please allow microphone access.';
                break;
            case 'network':
                errorMessage += 'Network error. Please check your connection.';
                break;
            case 'service-not-allowed':
                errorMessage += 'Speech recognition service not available.';
                break;
            default:
                errorMessage += event.error;
        }

        this.showErrorMessage(errorMessage);
        this.onRecognitionEnd();
    },

    /**
     * Handle recognition end
     */
    onRecognitionEnd() {
        this.isListening = false;
        this.updateVoiceButton(false);
        
        // Clear status after a delay
        setTimeout(() => {
            this.updateInputStatus('');
        }, 3000);

        // Remove visual feedback
        $('#voice-btn').removeClass('active');
    },

    /**
     * Update voice button state
     */
    updateVoiceButton(isActive) {
        const voiceBtn = $('#voice-btn');
        const icon = voiceBtn.find('i');
        
        if (isActive) {
            voiceBtn.addClass('active');
            icon.attr('data-feather', 'mic-off');
            voiceBtn.attr('title', 'Stop Voice Input');
        } else {
            voiceBtn.removeClass('active');
            icon.attr('data-feather', 'mic');
            voiceBtn.attr('title', 'Voice Input');
        }
        
        // Update feather icons
        feather.replace();
    },

    /**
     * Update input status message
     */
    updateInputStatus(message) {
        $('#input-status').text(message);
    },

    /**
     * Show error message
     */
    showErrorMessage(message) {
        this.updateInputStatus(message);
        
        // Also show in chat if available
        if (window.Chatbot) {
            setTimeout(() => {
                Chatbot.addMessage('bot', `Voice Recognition: ${message}`);
            }, 100);
        }
    },

    /**
     * Show unsupported message
     */
    showUnsupportedMessage() {
        const message = 'Voice recognition is not supported in your browser. Please try Chrome, Edge, or Safari.';
        this.showErrorMessage(message);
    },

    /**
     * Disable voice button
     */
    disableVoiceButton() {
        const voiceBtn = $('#voice-btn');
        voiceBtn.prop('disabled', true);
        voiceBtn.css('opacity', '0.5');
        voiceBtn.attr('title', 'Voice input not supported in this browser');
    },

    /**
     * Check if should auto-send message
     */
    shouldAutoSend(transcript) {
        // Auto-send for short, clear commands
        const autoSendPhrases = [
            'clear all', 'clear selections', 'apply filters',
            'show sales', 'show profit', 'show data'
        ];
        
        const lowerTranscript = transcript.toLowerCase().trim();
        return autoSendPhrases.some(phrase => lowerTranscript.includes(phrase));
    },

    /**
     * Set recognition language
     */
    setLanguage(language) {
        this.language = language;
        if (this.recognition) {
            this.recognition.lang = language;
        }
    },

    /**
     * Get available languages (common ones)
     */
    getAvailableLanguages() {
        return {
            'en-US': 'English (US)',
            'en-GB': 'English (UK)',
            'es-ES': 'Spanish (Spain)',
            'es-MX': 'Spanish (Mexico)',
            'fr-FR': 'French (France)',
            'de-DE': 'German (Germany)',
            'it-IT': 'Italian (Italy)',
            'pt-BR': 'Portuguese (Brazil)',
            'zh-CN': 'Chinese (Simplified)',
            'ja-JP': 'Japanese',
            'ko-KR': 'Korean'
        };
    },

    /**
     * Test microphone access
     */
    async testMicrophone() {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            stream.getTracks().forEach(track => track.stop());
            return true;
        } catch (error) {
            console.error('Microphone test failed:', error);
            return false;
        }
    }
};

// Export for use in other modules
window.VoiceRecognition = VoiceRecognition;
