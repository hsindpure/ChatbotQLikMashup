/**
 * QlikSense Mashup Integration
 * Handles QlikSense Capability API integration and app interactions
 */

const QlikSenseMashup = {
    app: null,
    currentUser: null,
    appName: null,
    fields: [],

    /**
     * Initialize the QlikSense mashup
     */
    init() {
        console.log('Initializing QlikSense Mashup...');
        this.setupRequireJS();
    },

    /**
     * Setup RequireJS configuration for QlikSense
     */
    setupRequireJS() {
        const config = {
            baseUrl: (window.location.hostname === 'localhost' || window.location.hostname.indexOf('dev-hub') > -1) 
                ? 'https://localhost:4848/resources' 
                : '/resources',
            paths: {
                qlik: 'js/qlik'
            }
        };

        require.config(config);
        
        require(['qlik'], (qlik) => {
            this.connectToQlik(qlik);
        });
    },

    /**
     * Connect to QlikSense and open app
     */
    connectToQlik(qlik) {
        try {
            // Configure QlikSense connection
            const qlikConfig = {
                host: window.location.hostname,
                prefix: '/',
                port: window.location.port || (window.location.protocol === 'https:' ? 443 : 80),
                isSecure: window.location.protocol === 'https:'
            };

            qlik.setOnError((error) => {
                console.error('QlikSense Error:', error);
                this.handleQlikError(error);
            });

            // Get current user info
            qlik.getGlobal().then((global) => {
                return global.getAuthenticatedUser();
            }).then((user) => {
                this.currentUser = user;
                $('#current-user').text(user.qUserId || 'Anonymous User');
                console.log('Authenticated user:', user);
            }).catch((error) => {
                console.warn('Could not get user info:', error);
                $('#current-user').text('Demo User');
                this.currentUser = { qUserId: 'demo_user', qUserName: 'Demo User' };
            });

            // Try to open an app (replace with actual app ID)
            const appId = this.getAppId();
            if (appId) {
                this.openApp(qlik, appId);
            } else {
                this.createDemoData();
            }

        } catch (error) {
            console.error('Failed to connect to QlikSense:', error);
            this.createDemoData();
        }
    },

    /**
     * Get app ID from URL or configuration
     */
    getAppId() {
        // Try to get app ID from URL parameters
        const urlParams = new URLSearchParams(window.location.search);
        const appId = urlParams.get('appid') || urlParams.get('app');
        
        // If no app ID in URL, you might want to use a default app ID
        // Replace 'your-default-app-id' with an actual app ID
        return appId || null;
    },

    /**
     * Open QlikSense app
     */
    openApp(qlik, appId) {
        qlik.openApp(appId).then((app) => {
            this.app = app;
            console.log('Connected to QlikSense app:', appId);
            
            // Get app info
            app.getAppObjectList().then((list) => {
                console.log('App objects:', list);
            });

            // Get app properties to get the app name
            app.getAppProperties().then((props) => {
                this.appName = props.qTitle || 'QlikSense Analytics';
                $('#app-name').text(`${this.appName} Assistant`);
            });

            // Get fields for field selector
            this.loadFields();
            
            // Create visualizations
            this.createVisualizations();

        }).catch((error) => {
            console.error('Failed to open QlikSense app:', error);
            this.createDemoData();
        });
    },

    /**
     * Load available fields from the app
     */
    loadFields() {
        if (!this.app) return;

        this.app.getList('FieldList').then((fieldList) => {
            const fieldSelector = $('#field-selector');
            fieldSelector.empty();
            fieldSelector.append('<option value="">Select Field</option>');

            fieldList.qFieldList.qItems.forEach((field) => {
                if (!field.qName.startsWith('$')) { // Skip system fields
                    fieldSelector.append(`<option value="${field.qName}">${field.qName}</option>`);
                    this.fields.push(field.qName);
                }
            });

            console.log('Loaded fields:', this.fields);
        }).catch((error) => {
            console.error('Failed to load fields:', error);
        });
    },

    /**
     * Create QlikSense visualizations
     */
    createVisualizations() {
        if (!this.app) return;

        // Create sample visualizations
        this.createVisualization('viz-1', {
            qHyperCubeDef: {
                qDimensions: [{
                    qDef: {
                        qFieldDefs: ['Month']
                    }
                }],
                qMeasures: [{
                    qDef: {
                        qDef: 'Sum(Sales)',
                        qLabel: 'Total Sales'
                    }
                }],
                qInitialDataFetch: [{
                    qWidth: 2,
                    qHeight: 50
                }]
            }
        });

        this.createVisualization('viz-2', {
            qHyperCubeDef: {
                qDimensions: [{
                    qDef: {
                        qFieldDefs: ['Region']
                    }
                }],
                qMeasures: [{
                    qDef: {
                        qDef: 'Sum(Profit)',
                        qLabel: 'Total Profit'
                    }
                }],
                qInitialDataFetch: [{
                    qWidth: 2,
                    qHeight: 50
                }]
            }
        });
    },

    /**
     * Create a single visualization
     */
    createVisualization(elementId, definition) {
        if (!this.app) return;

        this.app.createGenericObject(definition).then((model) => {
            model.getLayout().then((layout) => {
                this.renderVisualization(elementId, layout);
            });

            // Listen for data changes
            model.Validated.bind(() => {
                model.getLayout().then((layout) => {
                    this.renderVisualization(elementId, layout);
                });
            });

        }).catch((error) => {
            console.error(`Failed to create visualization ${elementId}:`, error);
        });
    },

    /**
     * Render visualization in the specified element
     */
    renderVisualization(elementId, layout) {
        const element = document.getElementById(elementId);
        if (!element) return;

        // Create a simple chart using the data
        const data = layout.qHyperCube.qDataPages[0].qMatrix;
        const labels = data.map(row => row[0].qText);
        const values = data.map(row => row[1].qNum);

        // Clear existing content
        element.innerHTML = `
            <h4>${layout.qHyperCube.qMeasureInfo[0].qFallbackTitle}</h4>
            <canvas id="${elementId}-chart" width="400" height="200"></canvas>
        `;

        // Create chart
        const ctx = document.getElementById(`${elementId}-chart`).getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: layout.qHyperCube.qMeasureInfo[0].qFallbackTitle,
                    data: values,
                    backgroundColor: 'rgba(102, 126, 234, 0.6)',
                    borderColor: 'rgba(102, 126, 234, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    },

    /**
     * Create demo data when QlikSense is not available
     */
    createDemoData() {
        console.log('Creating demo data...');
        this.appName = 'Sales Analytics Dashboard';
        $('#app-name').text('Analytics Assistant');
        $('#app-title').text(this.appName);
        $('#current-user').text('John Analyst');
        
        // Populate field selector with demo fields
        const demoFields = ['Sales', 'Profit', 'Region', 'Month', 'Product', 'Customer'];
        const fieldSelector = $('#field-selector');
        fieldSelector.empty();
        fieldSelector.append('<option value="">Select Field</option>');
        
        demoFields.forEach(field => {
            fieldSelector.append(`<option value="${field}">${field}</option>`);
            this.fields.push(field);
        });

        // Create demo visualizations
        this.createDemoVisualizations();
        
        // Create main revenue chart
        this.createMainRevenueChart();
    },

    /**
     * Create demo visualizations
     */
    createDemoVisualizations() {
        // Demo data for visualizations
        const salesData = {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
            values: [120000, 135000, 142000, 118000, 156000, 167000]
        };

        const regionData = {
            labels: ['North', 'South', 'East', 'West'],
            values: [45000, 38000, 52000, 41000]
        };

        this.renderDemoChart('viz-1', 'Monthly Sales', salesData, 'line');
        this.renderDemoChart('viz-2', 'Sales by Region', regionData, 'bar');
        this.renderDemoChart('viz-3', 'Profit Trend', salesData, 'area');
    },

    /**
     * Create main revenue chart for dashboard
     */
    createMainRevenueChart() {
        const ctx = document.getElementById('revenue-chart');
        if (!ctx) return;

        const data = {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            datasets: [{
                label: 'Revenue',
                data: [180000, 195000, 220000, 185000, 240000, 260000, 275000, 255000, 285000, 295000, 320000, 340000],
                borderColor: '#3b82f6',
                backgroundColor: 'rgba(59, 130, 246, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.4,
                pointRadius: 5,
                pointHoverRadius: 7,
                pointBackgroundColor: '#3b82f6',
                pointBorderColor: '#ffffff',
                pointBorderWidth: 2
            }]
        };

        new Chart(ctx.getContext('2d'), {
            type: 'line',
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleColor: '#ffffff',
                        bodyColor: '#ffffff',
                        borderColor: '#3b82f6',
                        borderWidth: 1,
                        callbacks: {
                            label: function(context) {
                                return 'Revenue: $' + context.parsed.y.toLocaleString();
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        },
                        border: {
                            display: false
                        }
                    },
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        },
                        border: {
                            display: false
                        },
                        ticks: {
                            callback: function(value) {
                                return '$' + (value / 1000) + 'K';
                            }
                        }
                    }
                },
                interaction: {
                    mode: 'nearest',
                    axis: 'x',
                    intersect: false
                }
            }
        });
    },

    /**
     * Render demo chart
     */
    renderDemoChart(elementId, title, data, type) {
        const element = document.getElementById(elementId);
        if (!element) return;

        element.innerHTML = `
            <h4>${title}</h4>
            <canvas id="${elementId}-chart" width="400" height="200"></canvas>
        `;

        const ctx = document.getElementById(`${elementId}-chart`).getContext('2d');
        new Chart(ctx, {
            type: type === 'area' ? 'line' : type,
            data: {
                labels: data.labels,
                datasets: [{
                    label: title,
                    data: data.values,
                    backgroundColor: type === 'area' ? 'rgba(102, 126, 234, 0.2)' : 'rgba(102, 126, 234, 0.6)',
                    borderColor: 'rgba(102, 126, 234, 1)',
                    borderWidth: 2,
                    fill: type === 'area'
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    },

    /**
     * Handle QlikSense errors
     */
    handleQlikError(error) {
        console.error('QlikSense Error:', error);
        // Fallback to demo mode
        this.createDemoData();
    },

    /**
     * Clear all selections in the app
     */
    clearSelections() {
        if (this.app) {
            this.app.clearAll().then(() => {
                console.log('All selections cleared');
                Chatbot.addMessage('bot', 'All selections have been cleared.');
            }).catch((error) => {
                console.error('Failed to clear selections:', error);
                Chatbot.addMessage('bot', 'Failed to clear selections. Please try again.');
            });
        } else {
            Chatbot.addMessage('bot', 'Demo mode: All selections cleared (simulated).');
        }
    },

    /**
     * Apply bookmark or default filters
     */
    applyBookmark() {
        if (this.app) {
            // Try to apply a default bookmark or filters
            this.app.getBookmarkList().then((bookmarks) => {
                if (bookmarks.qBookmarkList.qItems.length > 0) {
                    const bookmark = bookmarks.qBookmarkList.qItems[0];
                    return this.app.applyBookmark(bookmark.qInfo.qId);
                } else {
                    throw new Error('No bookmarks available');
                }
            }).then(() => {
                console.log('Bookmark applied');
                Chatbot.addMessage('bot', 'Default filters have been applied.');
            }).catch((error) => {
                console.log('No bookmarks available, applying demo filters');
                Chatbot.addMessage('bot', 'Default view has been set.');
            });
        } else {
            Chatbot.addMessage('bot', 'Demo mode: Default filters applied (simulated).');
        }
    },

    /**
     * Select values in a field
     */
    selectInField(fieldName, values) {
        if (this.app) {
            this.app.getField(fieldName).then((field) => {
                return field.selectValues(values);
            }).then(() => {
                console.log(`Selected values in ${fieldName}:`, values);
                Chatbot.addMessage('bot', `Selected "${values.join(', ')}" in field "${fieldName}".`);
            }).catch((error) => {
                console.error(`Failed to select in field ${fieldName}:`, error);
                Chatbot.addMessage('bot', `Failed to make selection in field "${fieldName}".`);
            });
        } else {
            Chatbot.addMessage('bot', `Demo mode: Selected "${values.join(', ')}" in field "${fieldName}" (simulated).`);
        }
    },

    /**
     * Get data for AI analysis
     */
    getDataForAnalysis(callback) {
        if (this.app) {
            // Create a hypercube to get current data state
            const definition = {
                qHyperCubeDef: {
                    qDimensions: [{
                        qDef: { qFieldDefs: ['Month'] }
                    }],
                    qMeasures: [
                        { qDef: { qDef: 'Sum(Sales)', qLabel: 'Sales' } },
                        { qDef: { qDef: 'Sum(Profit)', qLabel: 'Profit' } }
                    ],
                    qInitialDataFetch: [{ qWidth: 3, qHeight: 100 }]
                }
            };

            this.app.createGenericObject(definition).then((model) => {
                return model.getLayout();
            }).then((layout) => {
                const data = this.formatDataForAI(layout);
                callback(data);
            }).catch((error) => {
                console.error('Failed to get data for analysis:', error);
                // Return demo data
                callback(this.getDemoDataForAI());
            });
        } else {
            // Return demo data
            callback(this.getDemoDataForAI());
        }
    },

    /**
     * Format QlikSense data for AI analysis
     */
    formatDataForAI(layout) {
        const data = {
            appName: this.appName,
            currentUser: this.currentUser?.qUserId || 'demo_user',
            timestamp: new Date().toISOString(),
            metrics: {},
            dimensions: {},
            summary: {}
        };

        if (layout.qHyperCube && layout.qHyperCube.qDataPages[0]) {
            const matrix = layout.qHyperCube.qDataPages[0].qMatrix;
            const measures = layout.qHyperCube.qMeasureInfo;
            
            // Process data
            matrix.forEach(row => {
                const dimension = row[0].qText;
                measures.forEach((measure, index) => {
                    const measureName = measure.qFallbackTitle;
                    if (!data.metrics[measureName]) {
                        data.metrics[measureName] = [];
                    }
                    data.metrics[measureName].push({
                        dimension: dimension,
                        value: row[index + 1].qNum
                    });
                });
            });

            // Calculate summaries
            measures.forEach(measure => {
                const measureName = measure.qFallbackTitle;
                if (data.metrics[measureName]) {
                    const values = data.metrics[measureName].map(item => item.value);
                    data.summary[measureName] = {
                        total: values.reduce((sum, val) => sum + val, 0),
                        average: values.reduce((sum, val) => sum + val, 0) / values.length,
                        min: Math.min(...values),
                        max: Math.max(...values)
                    };
                }
            });
        }

        return data;
    },

    /**
     * Get demo data for AI analysis
     */
    getDemoDataForAI() {
        return {
            appName: 'Demo Analytics App',
            currentUser: 'demo_user',
            timestamp: new Date().toISOString(),
            metrics: {
                Sales: [
                    { dimension: 'Jan', value: 120000 },
                    { dimension: 'Feb', value: 135000 },
                    { dimension: 'Mar', value: 142000 },
                    { dimension: 'Apr', value: 118000 },
                    { dimension: 'May', value: 156000 },
                    { dimension: 'Jun', value: 167000 }
                ],
                Profit: [
                    { dimension: 'Jan', value: 24000 },
                    { dimension: 'Feb', value: 27000 },
                    { dimension: 'Mar', value: 28400 },
                    { dimension: 'Apr', value: 23600 },
                    { dimension: 'May', value: 31200 },
                    { dimension: 'Jun', value: 33400 }
                ]
            },
            summary: {
                Sales: { total: 838000, average: 139667, min: 118000, max: 167000 },
                Profit: { total: 167600, average: 27933, min: 23600, max: 33400 }
            }
        };
    }
};

// Setup event handlers when DOM is ready
$(document).ready(function() {
    // Clear selections button
    $('#clear-selections').on('click', function() {
        QlikSenseMashup.clearSelections();
    });

    // Apply bookmark button
    $('#apply-bookmark').on('click', function() {
        QlikSenseMashup.applyBookmark();
    });

    // Field selector change
    $('#field-selector').on('change', function() {
        const selectedField = $(this).val();
        if (selectedField) {
            Chatbot.addMessage('bot', `Selected field: ${selectedField}. You can now ask me questions about this field or make selections.`);
        }
    });
});
