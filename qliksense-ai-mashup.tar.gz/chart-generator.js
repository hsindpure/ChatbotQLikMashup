/**
 * Chart Generator Service
 * Handles dynamic chart creation based on user queries and data
 */

const ChartGenerator = {
    defaultColors: [
        'rgba(102, 126, 234, 0.8)',
        'rgba(118, 75, 162, 0.8)',
        'rgba(255, 99, 132, 0.8)',
        'rgba(54, 162, 235, 0.8)',
        'rgba(255, 205, 86, 0.8)',
        'rgba(75, 192, 192, 0.8)',
        'rgba(153, 102, 255, 0.8)',
        'rgba(255, 159, 64, 0.8)'
    ],

    /**
     * Generate chart from user query
     */
    async generateFromQuery(query, data, role) {
        try {
            console.log('Generating chart from query:', query);
            
            const chartType = this.determineChartType(query);
            const dataMapping = this.extractDataMapping(query, data);
            
            if (!dataMapping) {
                console.warn('Could not extract data mapping from query');
                return null;
            }

            const chartConfig = this.createChartConfig(chartType, dataMapping, role);
            
            return chartConfig;
        } catch (error) {
            console.error('Chart generation error:', error);
            return null;
        }
    },

    /**
     * Determine chart type from query
     */
    determineChartType(query) {
        const lowerQuery = query.toLowerCase();
        
        // Chart type keywords mapping
        const typeMapping = {
            'line': ['line', 'trend', 'over time', 'timeline', 'progression'],
            'bar': ['bar', 'column', 'compare', 'comparison', 'by region', 'by category'],
            'pie': ['pie', 'distribution', 'breakdown', 'share', 'percentage'],
            'doughnut': ['doughnut', 'donut', 'composition'],
            'scatter': ['scatter', 'correlation', 'relationship', 'vs'],
            'area': ['area', 'filled', 'cumulative']
        };

        // Find matching chart type
        for (const [type, keywords] of Object.entries(typeMapping)) {
            if (keywords.some(keyword => lowerQuery.includes(keyword))) {
                return type;
            }
        }

        // Default fallback based on data structure
        return 'bar';
    },

    /**
     * Extract data mapping from query and available data
     */
    extractDataMapping(query, data) {
        if (!data || !data.metrics) {
            return null;
        }

        const lowerQuery = query.toLowerCase();
        
        // Try to find specific metrics mentioned in query
        const mentionedMetrics = [];
        const mentionedDimensions = [];

        // Check for metric names in query
        Object.keys(data.metrics).forEach(metric => {
            if (lowerQuery.includes(metric.toLowerCase())) {
                mentionedMetrics.push(metric);
            }
        });

        // If no specific metrics mentioned, use all available
        const metricsToUse = mentionedMetrics.length > 0 ? mentionedMetrics : Object.keys(data.metrics);

        // Get dimensions from first metric
        const firstMetric = data.metrics[metricsToUse[0]];
        if (!firstMetric || !Array.isArray(firstMetric)) {
            return null;
        }

        const dimensions = firstMetric.map(item => item.dimension);

        return {
            dimensions: dimensions,
            metrics: metricsToUse,
            data: data.metrics
        };
    },

    /**
     * Create chart configuration
     */
    createChartConfig(type, dataMapping, role) {
        const { dimensions, metrics, data } = dataMapping;

        // Prepare datasets
        const datasets = metrics.map((metric, index) => {
            const metricData = data[metric];
            const values = metricData.map(item => item.value);
            
            return {
                label: metric,
                data: values,
                backgroundColor: this.getBackgroundColors(type, index, values.length),
                borderColor: this.getBorderColors(type, index),
                borderWidth: type === 'line' ? 3 : 1,
                fill: type === 'area',
                tension: type === 'line' ? 0.4 : 0,
                pointRadius: type === 'line' ? 4 : 0,
                pointHoverRadius: type === 'line' ? 6 : 0
            };
        });

        // Base configuration
        const config = {
            type: type === 'area' ? 'line' : type,
            data: {
                labels: dimensions,
                datasets: datasets
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: this.generateChartTitle(metrics, type),
                        font: {
                            size: 16,
                            weight: 'bold'
                        }
                    },
                    legend: {
                        display: metrics.length > 1,
                        position: 'top',
                        labels: {
                            padding: 20,
                            usePointStyle: true
                        }
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                        callbacks: {
                            label: function(context) {
                                return `${context.dataset.label}: ${context.parsed.y.toLocaleString()}`;
                            }
                        }
                    }
                },
                interaction: {
                    mode: 'nearest',
                    axis: 'x',
                    intersect: false
                }
            }
        };

        // Add scales for appropriate chart types
        if (type !== 'pie' && type !== 'doughnut') {
            config.options.scales = {
                x: {
                    title: {
                        display: true,
                        text: 'Category',
                        font: {
                            weight: 'bold'
                        }
                    },
                    grid: {
                        display: false
                    }
                },
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Value',
                        font: {
                            weight: 'bold'
                        }
                    },
                    grid: {
                        color: 'rgba(0, 0, 0, 0.1)'
                    }
                }
            };
        }

        // Apply role-based styling
        this.applyRoleBasedStyling(config, role);

        return config;
    },

    /**
     * Generate chart title
     */
    generateChartTitle(metrics, type) {
        if (metrics.length === 1) {
            return `${metrics[0]} Analysis`;
        } else {
            return `${metrics.join(' vs ')} Comparison`;
        }
    },

    /**
     * Get background colors for chart
     */
    getBackgroundColors(type, datasetIndex, dataLength) {
        if (type === 'pie' || type === 'doughnut') {
            // Return multiple colors for pie charts
            return this.defaultColors.slice(0, dataLength);
        } else {
            // Return single color for other chart types
            return this.defaultColors[datasetIndex % this.defaultColors.length];
        }
    },

    /**
     * Get border colors for chart
     */
    getBorderColors(type, datasetIndex) {
        const color = this.defaultColors[datasetIndex % this.defaultColors.length];
        return color.replace('0.8', '1'); // Make border fully opaque
    },

    /**
     * Apply role-based styling
     */
    applyRoleBasedStyling(config, role) {
        const roleThemes = {
            analyst: {
                colors: ['#667eea', '#764ba2', '#f093fb', '#4facfe'],
                gradient: true
            },
            hr: {
                colors: ['#4facfe', '#00f2fe', '#43e97b', '#38f9d7'],
                gradient: true
            },
            executive: {
                colors: ['#fa709a', '#fee140', '#667eea', '#764ba2'],
                gradient: true
            },
            operations: {
                colors: ['#ffecd2', '#fcb69f', '#667eea', '#a8edea'],
                gradient: false
            }
        };

        const theme = roleThemes[role] || roleThemes.analyst;
        
        // Update colors in datasets
        if (config.data.datasets) {
            config.data.datasets.forEach((dataset, index) => {
                const colorIndex = index % theme.colors.length;
                const baseColor = theme.colors[colorIndex];
                
                if (config.type === 'pie' || config.type === 'doughnut') {
                    dataset.backgroundColor = theme.colors.map(color => color + '80');
                    dataset.borderColor = theme.colors;
                } else {
                    dataset.backgroundColor = baseColor + '80';
                    dataset.borderColor = baseColor;
                }
            });
        }

        // Update chart styling
        config.options.plugins.title.color = theme.colors[0];
    },

    /**
     * Create quick comparison chart
     */
    createComparisonChart(currentData, benchmarkData, metric, role) {
        const labels = ['Current', 'Benchmark', 'Industry Average'];
        const values = [
            currentData[metric] || 0,
            benchmarkData[metric] || 0,
            benchmarkData[`${metric}_industry_avg`] || 0
        ];

        return {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: metric,
                    data: values,
                    backgroundColor: [
                        'rgba(102, 126, 234, 0.8)',
                        'rgba(255, 99, 132, 0.8)',
                        'rgba(255, 205, 86, 0.8)'
                    ],
                    borderColor: [
                        'rgba(102, 126, 234, 1)',
                        'rgba(255, 99, 132, 1)',
                        'rgba(255, 205, 86, 1)'
                    ],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: `${metric} Benchmark Comparison`,
                        font: {
                            size: 16,
                            weight: 'bold'
                        }
                    },
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Value'
                        }
                    }
                }
            }
        };
    },

    /**
     * Create trend chart
     */
    createTrendChart(data, metric, role) {
        if (!data.metrics || !data.metrics[metric]) {
            return null;
        }

        const metricData = data.metrics[metric];
        const labels = metricData.map(item => item.dimension);
        const values = metricData.map(item => item.value);

        return {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: metric,
                    data: values,
                    borderColor: 'rgba(102, 126, 234, 1)',
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointRadius: 5,
                    pointHoverRadius: 7
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: `${metric} Trend Analysis`,
                        font: {
                            size: 16,
                            weight: 'bold'
                        }
                    },
                    legend: {
                        display: false
                    }
                },
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'Time Period'
                        }
                    },
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: metric
                        }
                    }
                }
            }
        };
    },

    /**
     * Create distribution chart
     */
    createDistributionChart(data, dimension, role) {
        // This would create a pie chart showing distribution
        // Implementation depends on data structure
        return null;
    }
};

// Export for use in other modules
window.ChartGenerator = ChartGenerator;
