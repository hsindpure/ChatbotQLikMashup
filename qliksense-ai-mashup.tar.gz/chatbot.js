/**
 * Chatbot Interface and Logic
 * Handles chatbot UI interactions, message management, and coordination with other services
 */

const Chatbot = {
    isOpen: false,
    currentRole: 'analyst',
    messageContainer: null,
    inputField: null,
    sendButton: null,
    isProcessing: false,

    /**
     * Initialize the chatbot
     */
    init() {
        console.log('Initializing Chatbot...');
        this.setupElements();
        this.setupEventHandlers();
        this.setupRoleBasedGreeting();
    },

    /**
     * Setup DOM elements
     */
    setupElements() {
        this.messageContainer = $('#chatbot-messages');
        this.inputField = $('#message-input');
        this.sendButton = $('#send-btn');
    },

    /**
     * Setup event handlers
     */
    setupEventHandlers() {
        // Chatbot icon click
        $('#chatbot-icon').on('click', () => {
            this.toggleChatbot();
        });

        // Close button click
        $('#close-chatbot').on('click', () => {
            this.closeChatbot();
        });

        // Send button click
        this.sendButton.on('click', () => {
            this.sendMessage();
        });

        // Enter key press in input field
        this.inputField.on('keypress', (e) => {
            if (e.which === 13 && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });

        // Role selection change
        $('#user-role').on('change', (e) => {
            this.currentRole = e.target.value;
            $('#header-role').text(this.currentRole.charAt(0).toUpperCase() + this.currentRole.slice(1));
            this.handleRoleChange();
        });

        // Quick action buttons
        $(document).on('click', '.quick-action-btn', (e) => {
            const query = $(e.target).data('query');
            if (query) {
                this.inputField.val(query);
                this.sendMessage();
            }
        });

        // Prevent form submission
        this.inputField.on('keydown', (e) => {
            if (e.which === 13 && e.shiftKey) {
                // Allow shift+enter for line breaks
                return;
            }
        });
    },

    /**
     * Setup role-based greeting
     */
    setupRoleBasedGreeting() {
        const roleGreetings = {
            analyst: "I'm optimized to help you with data analysis, trend identification, and statistical insights.",
            hr: "I can assist with employee analytics, performance metrics, and HR-related data insights.",
            executive: "I'll focus on high-level KPIs, strategic insights, and executive dashboards.",
            operations: "I can help with operational metrics, efficiency analysis, and process optimization."
        };

        this.currentRole = $('#user-role').val();
        this.updateWelcomeMessage(roleGreetings[this.currentRole]);
    },

    /**
     * Update welcome message based on role
     */
    updateWelcomeMessage(roleSpecificText) {
        const welcomeMessage = $('.welcome-message .message-content p');
        if (welcomeMessage.length) {
            welcomeMessage.text(`Hello! I'm your AI Analytics Assistant. ${roleSpecificText} How can I assist you today?`);
        }
    },

    /**
     * Handle role change
     */
    handleRoleChange() {
        const roleMessages = {
            analyst: "I'm now optimized for data analysis tasks. Ask me about trends, correlations, or statistical insights.",
            hr: "I'm now focused on HR analytics. I can help with employee data, performance metrics, and workforce insights.",
            executive: "I'm now in executive mode. I'll prioritize strategic KPIs and high-level business insights.",
            operations: "I'm now optimized for operations. Ask me about efficiency metrics, process analysis, and operational KPIs."
        };

        this.addMessage('bot', `Role changed to ${this.currentRole.toUpperCase()}. ${roleMessages[this.currentRole]}`);
    },

    /**
     * Toggle chatbot visibility
     */
    toggleChatbot() {
        if (this.isOpen) {
            this.closeChatbot();
        } else {
            this.openChatbot();
        }
    },

    /**
     * Open chatbot
     */
    openChatbot() {
        $('#chatbot-popup').addClass('active');
        this.isOpen = true;
        
        // Focus on input field
        setTimeout(() => {
            this.inputField.focus();
        }, 400);

        // Scroll to bottom
        this.scrollToBottom();
    },

    /**
     * Close chatbot
     */
    closeChatbot() {
        $('#chatbot-popup').removeClass('active');
        this.isOpen = false;
    },

    /**
     * Send message
     */
    async sendMessage() {
        const message = this.inputField.val().trim();
        if (!message || this.isProcessing) return;

        // Disable input and show processing state
        this.setProcessingState(true);

        // Add user message
        this.addMessage('user', message);

        // Clear input
        this.inputField.val('');

        // Show typing indicator
        this.showTypingIndicator();

        try {
            // Process message based on content
            await this.processMessage(message);
        } catch (error) {
            console.error('Error processing message:', error);
            this.addMessage('bot', 'I apologize, but I encountered an error while processing your request. Please try again or rephrase your question.');
        } finally {
            this.hideTypingIndicator();
            this.setProcessingState(false);
        }
    },

    /**
     * Process user message
     */
    async processMessage(message) {
        const lowerMessage = message.toLowerCase();

        // Check for QlikSense operations
        if (this.isQlikSenseOperation(lowerMessage)) {
            this.handleQlikSenseOperation(lowerMessage, message);
            return;
        }

        // Check for chart/visualization requests
        if (this.isVisualizationRequest(lowerMessage)) {
            await this.handleVisualizationRequest(message);
            return;
        }

        // Get current data for context
        QlikSenseMashup.getDataForAnalysis((data) => {
            // Send to AI service for processing
            AIService.processQuery(message, {
                role: this.currentRole,
                qlikData: data,
                benchmarkData: BenchmarkData.getRelevantBenchmarks(this.currentRole)
            }).then((response) => {
                this.addMessage('bot', response.answer);
                
                // If response includes chart data, render it
                if (response.chartData) {
                    this.renderChart(response.chartData);
                }
            }).catch((error) => {
                console.error('AI Service error:', error);
                this.addMessage('bot', 'I apologize, but I\'m having trouble connecting to my AI service right now. Please try again in a moment.');
            });
        });
    },

    /**
     * Check if message is a QlikSense operation
     */
    isQlikSenseOperation(message) {
        const operations = [
            'clear selections', 'clear all', 'reset filters',
            'apply filters', 'apply bookmark', 'select',
            'filter by', 'show me', 'drill down'
        ];
        
        return operations.some(op => message.includes(op));
    },

    /**
     * Handle QlikSense operations
     */
    handleQlikSenseOperation(lowerMessage, originalMessage) {
        if (lowerMessage.includes('clear')) {
            QlikSenseMashup.clearSelections();
        } else if (lowerMessage.includes('apply') || lowerMessage.includes('bookmark')) {
            QlikSenseMashup.applyBookmark();
        } else if (lowerMessage.includes('select') || lowerMessage.includes('filter')) {
            this.handleSelectionRequest(originalMessage);
        } else {
            this.addMessage('bot', 'I understand you want to perform a QlikSense operation. Could you please be more specific about what you\'d like to do?');
        }
    },

    /**
     * Handle selection requests
     */
    handleSelectionRequest(message) {
        // Simple pattern matching for selections
        const patterns = [
            /select\s+(.+)\s+in\s+(.+)/i,
            /filter\s+(.+)\s+by\s+(.+)/i,
            /show\s+(.+)\s+for\s+(.+)/i
        ];

        for (let pattern of patterns) {
            const match = message.match(pattern);
            if (match) {
                const values = match[1].split(/,|\s+and\s+/).map(v => v.trim());
                const field = match[2].trim();
                
                if (QlikSenseMashup.fields.includes(field)) {
                    QlikSenseMashup.selectInField(field, values);
                    return;
                }
            }
        }

        this.addMessage('bot', 'I understand you want to make a selection. Please specify the field and values, for example: "Select North, South in Region" or use the field selector above.');
    },

    /**
     * Check if message is a visualization request
     */
    isVisualizationRequest(message) {
        const vizKeywords = [
            'chart', 'graph', 'plot', 'visualize', 'show chart',
            'create chart', 'draw', 'table', 'bar chart', 'line chart',
            'pie chart', 'trend', 'comparison'
        ];
        
        return vizKeywords.some(keyword => message.includes(keyword));
    },

    /**
     * Handle visualization requests
     */
    async handleVisualizationRequest(message) {
        try {
            // Get current data
            QlikSenseMashup.getDataForAnalysis((data) => {
                // Use chart generator to create visualization
                ChartGenerator.generateFromQuery(message, data, this.currentRole)
                    .then((chartConfig) => {
                        if (chartConfig) {
                            this.addMessage('bot', 'Here\'s the visualization you requested:');
                            this.renderChart(chartConfig);
                        } else {
                            this.addMessage('bot', 'I couldn\'t generate a chart based on your request. Please be more specific about what data you\'d like to visualize.');
                        }
                    })
                    .catch((error) => {
                        console.error('Chart generation error:', error);
                        this.addMessage('bot', 'I encountered an error while creating the chart. Please try rephrasing your request.');
                    });
            });
        } catch (error) {
            console.error('Visualization request error:', error);
            this.addMessage('bot', 'I\'m sorry, but I couldn\'t process your visualization request. Please try again.');
        }
    },

    /**
     * Add message to chat
     */
    addMessage(sender, content, timestamp = null) {
        const messageTime = timestamp || new Date();
        const timeString = messageTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        
        const isUser = sender === 'user';
        const userName = isUser ? (QlikSenseMashup.currentUser?.qUserName || 'You') : 'Analytics Assistant';
        const avatarIcon = isUser ? 'user' : 'message-circle';
        const messageClass = isUser ? 'user-message' : 'bot-message';
        const avatarClass = isUser ? 'user-avatar-msg' : 'bot-avatar';

        const messageHtml = `
            <div class="message ${messageClass}">
                <div class="message-avatar ${avatarClass}">
                    <i data-feather="${avatarIcon}"></i>
                </div>
                <div class="message-content">
                    <p>${content}</p>
                    <span class="message-time" style="font-size: 0.7rem; opacity: 0.7; margin-top: 0.5rem; display: block;">${timeString}</span>
                </div>
            </div>
        `;

        this.messageContainer.append(messageHtml);
        
        // Replace feather icons
        feather.replace();
        
        // Scroll to bottom
        this.scrollToBottom();
    },

    /**
     * Render chart in chat
     */
    renderChart(chartConfig) {
        const chartId = `chart-${Date.now()}`;
        const chartHtml = `
            <div class="message bot-message">
                <div class="message-avatar bot-avatar">
                    <i data-feather="bar-chart-2"></i>
                </div>
                <div class="message-content">
                    <div class="chart-container">
                        <canvas id="${chartId}" width="300" height="200"></canvas>
                    </div>
                </div>
            </div>
        `;

        this.messageContainer.append(chartHtml);
        
        // Replace feather icons
        feather.replace();

        // Create chart
        setTimeout(() => {
            const ctx = document.getElementById(chartId);
            if (ctx) {
                new Chart(ctx.getContext('2d'), chartConfig);
            }
        }, 100);

        this.scrollToBottom();
    },

    /**
     * Show typing indicator
     */
    showTypingIndicator() {
        const typingHtml = `
            <div class="typing-indicator" id="typing-indicator">
                <div class="message-avatar bot-avatar">
                    <i data-feather="brain"></i>
                </div>
                <div class="typing-content">
                    <span>AI is thinking</span>
                    <div class="typing-dots">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </div>
            </div>
        `;

        this.messageContainer.append(typingHtml);
        feather.replace();
        this.scrollToBottom();
    },

    /**
     * Hide typing indicator
     */
    hideTypingIndicator() {
        $('#typing-indicator').remove();
    },

    /**
     * Set processing state
     */
    setProcessingState(processing) {
        this.isProcessing = processing;
        this.sendButton.prop('disabled', processing);
        this.inputField.prop('disabled', processing);
        
        if (processing) {
            this.sendButton.find('i').attr('data-feather', 'loader');
            $('#input-status').text('Processing...');
        } else {
            this.sendButton.find('i').attr('data-feather', 'send');
            $('#input-status').text('');
        }
        
        feather.replace();
    },

    /**
     * Scroll to bottom of messages
     */
    scrollToBottom() {
        setTimeout(() => {
            this.messageContainer.scrollTop(this.messageContainer[0].scrollHeight);
        }, 100);
    },

    /**
     * Show loading overlay
     */
    showLoading(message = 'Processing your request...') {
        $('#loading-overlay .loading-spinner p').text(message);
        $('#loading-overlay').addClass('active');
    },

    /**
     * Hide loading overlay
     */
    hideLoading() {
        $('#loading-overlay').removeClass('active');
    }
};

// Export for use in other modules
window.Chatbot = Chatbot;
