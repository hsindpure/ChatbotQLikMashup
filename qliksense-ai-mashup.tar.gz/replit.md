# QlikSense AI Analytics Mashup

## Overview

This is a client-side web application that integrates QlikSense analytics with AI-powered natural language processing capabilities. The application provides an interactive dashboard where users can query data using natural language, generate charts dynamically, and interact with QlikSense visualizations through an AI-powered chatbot interface.

## System Architecture

### Frontend Architecture
- **Pure HTML/CSS/JavaScript**: Client-side application using vanilla JavaScript with jQuery for DOM manipulation
- **Modular Design**: Separated into distinct service modules for different functionalities
- **Real-time Interaction**: Voice recognition and chatbot interface for natural language queries
- **Responsive UI**: Modern gradient-based design with glassmorphism effects

### Backend Architecture
- **Client-side Only**: No dedicated backend server; all processing happens in the browser
- **External API Integration**: Direct integration with OpenAI API for natural language processing
- **QlikSense Integration**: Uses QlikSense Capability API for data visualization and analytics

## Key Components

### 1. AI Service (`ai-service.js`)
- **Purpose**: Handles communication with OpenAI's GPT-4o model for natural language processing
- **Features**: Query processing, system prompt building, API key management
- **API Integration**: Direct calls to OpenAI's REST API

### 2. QlikSense Mashup (`qliksense-mashup.js`)
- **Purpose**: Integrates with QlikSense Capability API for data visualization
- **Features**: App connection, field management, visualization rendering
- **Configuration**: Supports both localhost development and production environments

### 3. Chatbot Interface (`chatbot.js`)
- **Purpose**: Provides conversational interface for data queries
- **Features**: Message management, role-based interactions, query processing coordination
- **UI Components**: Collapsible chat interface with message history

### 4. Chart Generator (`chart-generator.js`)
- **Purpose**: Dynamically creates charts based on natural language queries
- **Features**: Chart type detection, data mapping, Chart.js integration
- **Visualization**: Supports multiple chart types with role-based styling

### 5. Voice Recognition (`voice-recognition.js`)
- **Purpose**: Enables speech-to-text functionality for hands-free interaction
- **Technology**: Web Speech API (webkit/standard)
- **Features**: Real-time transcription, language support, browser compatibility checks

### 6. Benchmark Data (`benchmark-data.js`)
- **Purpose**: Provides industry benchmark data for comparative analysis
- **Data**: Pre-defined benchmarks across multiple industries (retail, technology, manufacturing, financial services, healthcare)
- **Metrics**: Sales growth, profit margins, customer retention, productivity measures

## Data Flow

1. **User Input**: Users can interact through text input, voice commands, or direct chart requests
2. **Natural Language Processing**: Queries are processed by the AI service using OpenAI's GPT-4o
3. **Data Interpretation**: AI service interprets user intent and maps to available data
4. **Visualization Generation**: Chart generator creates appropriate visualizations using Chart.js
5. **QlikSense Integration**: Complex analytics are handled through QlikSense Capability API
6. **Response Delivery**: Results are presented through the chatbot interface and visual charts

## External Dependencies

### Core Libraries
- **jQuery 3.6.0**: DOM manipulation and AJAX requests
- **Chart.js**: Dynamic chart generation and rendering
- **Feather Icons**: Modern icon library for UI elements
- **QlikSense Capability API**: Integration with QlikSense analytics platform

### API Services
- **OpenAI API**: GPT-4o model for natural language processing
- **Web Speech API**: Browser-native speech recognition (webkit/standard)

### Development Dependencies
- **RequireJS**: Module loading for QlikSense integration
- **OpenAI Node.js SDK**: Server-side OpenAI integration (npm package)

## Deployment Strategy

### Client-Side Deployment
- **Static Hosting**: Can be deployed on any static web host or CDN
- **HTTPS Required**: Necessary for voice recognition and secure API calls
- **Environment Configuration**: API keys managed through environment variables or localStorage

### QlikSense Integration
- **Development**: Localhost configuration for development environment
- **Production**: Configurable host/port settings for production QlikSense instances
- **Security**: Relies on QlikSense's built-in authentication and authorization

### API Key Management
- **Development**: localStorage or global variables for testing
- **Production**: Environment variables or secure configuration management
- **Fallback**: Placeholder values that require manual configuration

## Changelog

```
Changelog:
- July 01, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```

### Key Architectural Decisions

1. **Client-Side Architecture**: Chosen for simplicity and direct browser integration, avoiding server infrastructure complexity
2. **Modular JavaScript Design**: Separated concerns into distinct service modules for maintainability and testing
3. **OpenAI GPT-4o Integration**: Selected for advanced natural language understanding capabilities
4. **QlikSense Capability API**: Provides enterprise-grade analytics capabilities without custom data processing
5. **Voice Recognition**: Enhances accessibility and provides hands-free interaction for dashboard users
6. **Chart.js for Visualization**: Lightweight, flexible charting library with good browser support
7. **Industry Benchmark Data**: Hard-coded benchmarks provide immediate comparative analysis capabilities

The architecture prioritizes rapid development, browser compatibility, and seamless integration with existing QlikSense deployments while providing modern AI-powered interaction capabilities.