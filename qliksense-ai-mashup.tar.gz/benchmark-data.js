/**
 * Benchmark Data Service
 * Provides external market and industry benchmark data for comparison
 */

const BenchmarkData = {
    // Industry benchmark data by sector
    industryBenchmarks: {
        retail: {
            sales_growth_rate: 0.15,
            profit_margin: 0.05,
            customer_retention: 0.75,
            inventory_turnover: 8.5,
            employee_productivity: 145000,
            market_share: 0.12
        },
        technology: {
            sales_growth_rate: 0.25,
            profit_margin: 0.18,
            customer_retention: 0.85,
            r_and_d_spending: 0.15,
            employee_productivity: 225000,
            market_share: 0.08
        },
        manufacturing: {
            sales_growth_rate: 0.08,
            profit_margin: 0.12,
            operational_efficiency: 0.82,
            quality_score: 0.95,
            employee_productivity: 185000,
            market_share: 0.15
        },
        financial_services: {
            sales_growth_rate: 0.12,
            profit_margin: 0.22,
            customer_retention: 0.88,
            risk_score: 0.03,
            employee_productivity: 275000,
            market_share: 0.10
        },
        healthcare: {
            sales_growth_rate: 0.10,
            profit_margin: 0.15,
            patient_satisfaction: 0.85,
            operational_efficiency: 0.78,
            employee_productivity: 195000,
            market_share: 0.11
        }
    },

    // Global market benchmarks
    globalBenchmarks: {
        economic_indicators: {
            gdp_growth: 0.032,
            inflation_rate: 0.025,
            unemployment_rate: 0.045,
            currency_stability: 0.92
        },
        business_metrics: {
            average_profit_margin: 0.15,
            average_growth_rate: 0.12,
            employee_satisfaction: 0.72,
            digital_adoption: 0.68
        }
    },

    // Role-specific benchmark categories
    roleBenchmarks: {
        analyst: [
            'sales_growth_rate', 'profit_margin', 'market_share',
            'operational_efficiency', 'customer_retention'
        ],
        hr: [
            'employee_productivity', 'employee_satisfaction', 'retention_rate',
            'training_effectiveness', 'diversity_index'
        ],
        executive: [
            'profit_margin', 'sales_growth_rate', 'market_share',
            'shareholder_value', 'strategic_goals_achievement'
        ],
        operations: [
            'operational_efficiency', 'quality_score', 'cost_reduction',
            'process_optimization', 'supply_chain_efficiency'
        ]
    },

    // Time-series benchmark data
    timeSeriesBenchmarks: {
        monthly_sales_trends: [
            { month: 'Jan', industry_avg: 120000, top_quartile: 180000 },
            { month: 'Feb', industry_avg: 125000, top_quartile: 185000 },
            { month: 'Mar', industry_avg: 135000, top_quartile: 195000 },
            { month: 'Apr', industry_avg: 130000, top_quartile: 190000 },
            { month: 'May', industry_avg: 140000, top_quartile: 200000 },
            { month: 'Jun', industry_avg: 145000, top_quartile: 210000 }
        ],
        quarterly_profit: [
            { quarter: 'Q1', industry_avg: 25000, top_quartile: 45000 },
            { quarter: 'Q2', industry_avg: 28000, top_quartile: 48000 },
            { quarter: 'Q3', industry_avg: 32000, top_quartile: 52000 },
            { quarter: 'Q4', industry_avg: 35000, top_quartile: 55000 }
        ]
    },

    // Geographic benchmarks
    geographicBenchmarks: {
        north_america: {
            sales_per_capita: 850,
            market_penetration: 0.42,
            customer_satisfaction: 0.78,
            competitive_index: 0.85
        },
        europe: {
            sales_per_capita: 720,
            market_penetration: 0.38,
            customer_satisfaction: 0.82,
            competitive_index: 0.78
        },
        asia_pacific: {
            sales_per_capita: 650,
            market_penetration: 0.35,
            customer_satisfaction: 0.75,
            competitive_index: 0.90
        }
    },

    /**
     * Get relevant benchmarks based on user role
     */
    getRelevantBenchmarks(role, industry = 'technology') {
        const relevantMetrics = this.roleBenchmarks[role] || this.roleBenchmarks.analyst;
        const industryData = this.industryBenchmarks[industry] || this.industryBenchmarks.technology;
        
        const benchmarks = {
            role: role,
            industry: industry,
            metrics: {},
            global_context: this.globalBenchmarks,
            time_series: this.getTimeSeriesBenchmarks(role),
            geographic: this.geographicBenchmarks
        };

        // Extract relevant metrics
        relevantMetrics.forEach(metric => {
            if (industryData[metric] !== undefined) {
                benchmarks.metrics[metric] = {
                    industry_average: industryData[metric],
                    global_average: this.getGlobalAverage(metric),
                    top_quartile: this.getTopQuartile(metric, industry),
                    bottom_quartile: this.getBottomQuartile(metric, industry)
                };
            }
        });

        return benchmarks;
    },

    /**
     * Get time series benchmarks relevant to role
     */
    getTimeSeriesBenchmarks(role) {
        const roleTimeSeries = {
            analyst: ['monthly_sales_trends', 'quarterly_profit'],
            hr: ['employee_satisfaction_trends', 'retention_trends'],
            executive: ['quarterly_profit', 'market_share_trends'],
            operations: ['efficiency_trends', 'quality_trends']
        };

        const relevantSeries = roleTimeSeries[role] || roleTimeSeries.analyst;
        const result = {};

        relevantSeries.forEach(series => {
            if (this.timeSeriesBenchmarks[series]) {
                result[series] = this.timeSeriesBenchmarks[series];
            }
        });

        return result;
    },

    /**
     * Get global average for a metric
     */
    getGlobalAverage(metric) {
        // Calculate average across all industries
        const industries = Object.values(this.industryBenchmarks);
        const values = industries
            .map(industry => industry[metric])
            .filter(value => value !== undefined);
        
        if (values.length === 0) return null;
        
        return values.reduce((sum, value) => sum + value, 0) / values.length;
    },

    /**
     * Get top quartile value for a metric
     */
    getTopQuartile(metric, industry) {
        const baseValue = this.industryBenchmarks[industry]?.[metric];
        if (!baseValue) return null;
        
        // Top quartile is typically 25% above industry average
        return baseValue * 1.25;
    },

    /**
     * Get bottom quartile value for a metric
     */
    getBottomQuartile(metric, industry) {
        const baseValue = this.industryBenchmarks[industry]?.[metric];
        if (!baseValue) return null;
        
        // Bottom quartile is typically 25% below industry average
        return baseValue * 0.75;
    },

    /**
     * Compare company data with benchmarks
     */
    compareWithBenchmarks(companyData, role, industry = 'technology') {
        const benchmarks = this.getRelevantBenchmarks(role, industry);
        const comparison = {
            company: companyData,
            benchmarks: benchmarks,
            analysis: {},
            recommendations: []
        };

        // Analyze each metric
        Object.keys(benchmarks.metrics).forEach(metric => {
            const companyValue = this.extractMetricValue(companyData, metric);
            const benchmark = benchmarks.metrics[metric];
            
            if (companyValue !== null && benchmark) {
                const analysis = this.analyzeMetricPerformance(
                    companyValue, 
                    benchmark, 
                    metric
                );
                
                comparison.analysis[metric] = analysis;
                
                if (analysis.recommendation) {
                    comparison.recommendations.push({
                        metric: metric,
                        recommendation: analysis.recommendation,
                        priority: analysis.priority
                    });
                }
            }
        });

        return comparison;
    },

    /**
     * Extract metric value from company data
     */
    extractMetricValue(data, metric) {
        // Handle different data structures
        if (data.summary && data.summary[metric]) {
            return data.summary[metric].total || data.summary[metric].average;
        }
        
        if (data.metrics && data.metrics[metric]) {
            const metricData = data.metrics[metric];
            if (Array.isArray(metricData)) {
                // Calculate total or average
                const values = metricData.map(item => item.value || 0);
                return values.reduce((sum, val) => sum + val, 0);
            }
            return metricData;
        }
        
        // Direct property access
        return data[metric] || null;
    },

    /**
     * Analyze metric performance against benchmarks
     */
    analyzeMetricPerformance(companyValue, benchmark, metric) {
        const industryAvg = benchmark.industry_average;
        const topQuartile = benchmark.top_quartile;
        const bottomQuartile = benchmark.bottom_quartile;
        
        const performance = companyValue / industryAvg;
        
        let status, recommendation, priority;
        
        if (performance >= 1.25) {
            status = 'excellent';
            recommendation = `${metric} is performing excellently, well above industry standards.`;
            priority = 'low';
        } else if (performance >= 1.1) {
            status = 'good';
            recommendation = `${metric} is performing well, above industry average.`;
            priority = 'low';
        } else if (performance >= 0.9) {
            status = 'average';
            recommendation = `${metric} is performing at industry average levels.`;
            priority = 'medium';
        } else if (performance >= 0.75) {
            status = 'below_average';
            recommendation = `${metric} is below industry average and needs attention.`;
            priority = 'high';
        } else {
            status = 'poor';
            recommendation = `${metric} is significantly below industry standards and requires immediate action.`;
            priority = 'critical';
        }
        
        return {
            company_value: companyValue,
            industry_average: industryAvg,
            performance_ratio: performance,
            status: status,
            recommendation: recommendation,
            priority: priority,
            gap_to_top_quartile: topQuartile - companyValue,
            percentile: this.calculatePercentile(performance)
        };
    },

    /**
     * Calculate percentile based on performance ratio
     */
    calculatePercentile(performanceRatio) {
        if (performanceRatio >= 1.25) return 90;
        if (performanceRatio >= 1.1) return 75;
        if (performanceRatio >= 1.0) return 60;
        if (performanceRatio >= 0.9) return 40;
        if (performanceRatio >= 0.75) return 25;
        return 10;
    },

    /**
     * Get industry trends
     */
    getIndustryTrends(industry = 'technology') {
        return {
            growth_forecast: {
                '2024': 0.15,
                '2025': 0.18,
                '2026': 0.22
            },
            emerging_metrics: [
                'digital_transformation_index',
                'sustainability_score',
                'customer_experience_rating',
                'innovation_index'
            ],
            risk_factors: [
                'market_volatility',
                'regulatory_changes',
                'technology_disruption',
                'competitive_pressure'
            ]
        };
    },

    /**
     * Get benchmark summary for role
     */
    getBenchmarkSummary(role, industry = 'technology') {
        const benchmarks = this.getRelevantBenchmarks(role, industry);
        
        return {
            role: role,
            industry: industry,
            key_metrics_count: Object.keys(benchmarks.metrics).length,
            performance_indicators: Object.keys(benchmarks.metrics),
            summary: `Benchmark data for ${role} in ${industry} industry includes ${Object.keys(benchmarks.metrics).length} key performance indicators.`,
            last_updated: new Date().toISOString(),
            data_sources: [
                'Industry Research Reports',
                'Market Analysis Data',
                'Public Company Filings',
                'Government Statistics'
            ]
        };
    }
};

// Export for use in other modules
window.BenchmarkData = BenchmarkData;
