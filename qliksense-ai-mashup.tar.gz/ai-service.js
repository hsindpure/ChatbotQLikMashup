/**
 * AI Service Integration
 * Handles communication with AI API (OpenAI) for natural language processing
 */

const AIService = {
    apiKey: null,
    baseUrl: 'https://api.openai.com/v1',
    model: 'gpt-4o', // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user

    /**
     * Initialize AI service
     */
    init() {
        // Get API key from environment or use default
        this.apiKey = this.getApiKey();
        console.log('AI Service initialized');
    },

    /**
     * Get API key from environment variables
     */
    getApiKey() {
        // In a real environment, this would come from server-side environment variables
        // For client-side demo, we'll check for a global variable or localStorage
        return window.OPENAI_API_KEY || 
               localStorage.getItem('OPENAI_API_KEY') || 
               'your-openai-api-key-here'; // Fallback - should be replaced with actual key
    },

    /**
     * Process user query with AI
     */
    async processQuery(query, context = {}) {
        try {
            const systemPrompt = this.buildSystemPrompt(context);
            const userPrompt = this.buildUserPrompt(query, context);

            const response = await this.callOpenAI(systemPrompt, userPrompt);
            
            return this.parseAIResponse(response, context);
        } catch (error) {
            console.error('AI Service error:', error);
            throw new Error('Failed to process query with AI service');
        }
    },

    /**
     * Build system prompt based on context
     */
    buildSystemPrompt(context) {
        const { role, qlikData } = context;
        
        let systemPrompt = `You are an AI assistant integrated with QlikSense business intelligence software. `;
        
        // Role-specific instructions
        switch (role) {
            case 'analyst':
                systemPrompt += `You are helping a data analyst. Focus on detailed statistical analysis, trend identification, data correlations, and technical insights. Provide specific numbers and analytical depth.`;
                break;
            case 'hr':
                systemPrompt += `You are helping an HR manager. Focus on employee-related metrics, workforce analytics, performance insights, and people-related KPIs. Consider HR best practices and compliance.`;
                break;
            case 'executive':
                systemPrompt += `You are helping an executive. Focus on high-level strategic insights, key performance indicators, business impact, and executive-level summaries. Keep responses concise and actionable.`;
                break;
            case 'operations':
                systemPrompt += `You are helping an operations manager. Focus on operational efficiency, process optimization, cost analysis, and operational KPIs. Emphasize practical improvements.`;
                break;
            default:
                systemPrompt += `You are helping a business user analyze their data. Provide clear, actionable insights.`;
        }

        systemPrompt += `

IMPORTANT INSTRUCTIONS:
1. Always base your answers on the actual QlikSense data provided
2. When comparing with benchmarks, clearly distinguish between actual data and benchmark comparisons
3. If asked to create charts, respond with JSON in this format: {"answer": "text response", "chartData": {"type": "bar|line|pie", "data": {...}}}
4. For QlikSense operations, acknowledge the action and explain what was done
5. Be specific with numbers and metrics from the actual data
6. If data is insufficient, clearly state what additional data would be helpful

Current QlikSense App: ${qlikData?.appName || 'Unknown App'}
User: ${qlikData?.currentUser || 'Unknown User'}
Timestamp: ${qlikData?.timestamp || new Date().toISOString()}`;

        return systemPrompt;
    },

    /**
     * Build user prompt with context
     */
    buildUserPrompt(query, context) {
        const { qlikData, benchmarkData } = context;
        
        let prompt = `User Query: "${query}"

CURRENT QLIKSENSE DATA:
${JSON.stringify(qlikData, null, 2)}`;

        if (benchmarkData && Object.keys(benchmarkData).length > 0) {
            prompt += `

RELEVANT BENCHMARK DATA FOR COMPARISON:
${JSON.stringify(benchmarkData, null, 2)}`;
        }

        prompt += `

Please analyze this data and respond to the user's query. If the query requests a visualization, include chartData in your JSON response.`;

        return prompt;
    },

    /**
     * Call OpenAI API
     */
    async callOpenAI(systemPrompt, userPrompt) {
        const requestBody = {
            model: this.model,
            messages: [
                {
                    role: "system",
                    content: systemPrompt
                },
                {
                    role: "user",
                    content: userPrompt
                }
            ],
            response_format: { type: "json_object" },
            temperature: 0.7,
            max_tokens: 1500
        };

        const response = await fetch(`${this.baseUrl}/chat/completions`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${this.apiKey}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestBody)
        });

        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(`OpenAI API error: ${response.status} - ${errorData.error?.message || 'Unknown error'}`);
        }

        const data = await response.json();
        return data.choices[0].message.content;
    },

    /**
     * Parse AI response
     */
    parseAIResponse(response, context) {
        try {
            const parsed = JSON.parse(response);
            
            // Validate response structure
            if (!parsed.answer) {
                throw new Error('Invalid response format: missing answer');
            }

            // Process chart data if present
            if (parsed.chartData) {
                parsed.chartData = this.processChartData(parsed.chartData, context);
            }

            return parsed;
        } catch (error) {
            console.error('Failed to parse AI response:', error);
            
            // Fallback: treat entire response as answer
            return {
                answer: response || 'I apologize, but I received an unexpected response format. Please try rephrasing your question.',
                chartData: null
            };
        }
    },

    /**
     * Process chart data to ensure it's in the correct format
     */
    processChartData(chartData, context) {
        if (!chartData || !chartData.type || !chartData.data) {
            return null;
        }

        // Convert to Chart.js format
        const chartConfig = {
            type: chartData.type,
            data: chartData.data,
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: chartData.title || 'Data Visualization'
                    },
                    legend: {
                        display: true,
                        position: 'top'
                    }
                },
                scales: {}
            }
        };

        // Add scales for bar and line charts
        if (chartData.type === 'bar' || chartData.type === 'line') {
            chartConfig.options.scales = {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: chartData.yAxisLabel || 'Value'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: chartData.xAxisLabel || 'Category'
                    }
                }
            };
        }

        // Style the chart based on role
        this.applyRoleBasedStyling(chartConfig, context.role);

        return chartConfig;
    },

    /**
     * Apply role-based styling to charts
     */
    applyRoleBasedStyling(chartConfig, role) {
        const roleColors = {
            analyst: ['#667eea', '#764ba2', '#f093fb'],
            hr: ['#4facfe', '#00f2fe', '#43e97b'],
            executive: ['#fa709a', '#fee140', '#667eea'],
            operations: ['#ffecd2', '#fcb69f', '#667eea']
        };

        const colors = roleColors[role] || roleColors.analyst;

        if (chartConfig.data.datasets) {
            chartConfig.data.datasets.forEach((dataset, index) => {
                const colorIndex = index % colors.length;
                dataset.backgroundColor = colors[colorIndex] + '80'; // Add transparency
                dataset.borderColor = colors[colorIndex];
                dataset.borderWidth = 2;
            });
        }
    },

    /**
     * Generate analysis summary
     */
    async generateSummary(data, role) {
        try {
            const systemPrompt = `You are a business intelligence assistant. Create a concise summary of the provided data for a ${role}. Focus on key insights, trends, and actionable recommendations.`;
            
            const userPrompt = `Analyze this QlikSense data and provide a summary:
${JSON.stringify(data, null, 2)}

Provide insights relevant to a ${role} role.`;

            const response = await this.callOpenAI(systemPrompt, userPrompt);
            const parsed = JSON.parse(response);
            
            return parsed.answer || parsed.summary || 'Summary not available';
        } catch (error) {
            console.error('Failed to generate summary:', error);
            return 'Unable to generate summary at this time.';
        }
    },

    /**
     * Get data insights
     */
    async getDataInsights(data, query, role) {
        try {
            const systemPrompt = `You are analyzing QlikSense business data. Provide specific insights based on the data and user query. Focus on ${role}-relevant insights.`;
            
            const userPrompt = `Query: "${query}"
Data: ${JSON.stringify(data, null, 2)}

Provide specific insights and recommendations based on this data.`;

            const response = await this.callOpenAI(systemPrompt, userPrompt);
            const parsed = JSON.parse(response);
            
            return parsed.answer || 'No insights available';
        } catch (error) {
            console.error('Failed to get insights:', error);
            return 'Unable to generate insights at this time.';
        }
    }
};

// Initialize AI service when script loads
AIService.init();

// Export for use in other modules
window.AIService = AIService;
