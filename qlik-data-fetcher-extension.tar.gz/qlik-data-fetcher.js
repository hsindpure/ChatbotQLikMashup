define([
    'qlik',
    'jquery',
    'text!./qlik-data-fetcher.html',
    'css!./qlik-data-fetcher.css'
], function(qlik, $, template) {
    'use strict';

    return {
        definition: {
            type: "items",
            component: "accordion",
            items: {
                settings: {
                    uses: "settings",
                    items: {
                        general: {
                            type: "items",
                            label: "General Settings",
                            items: {
                                refreshInterval: {
                                    type: "number",
                                    label: "Auto-refresh interval (seconds)",
                                    ref: "refreshInterval",
                                    defaultValue: 30,
                                    min: 5,
                                    max: 300
                                },
                                maxObjects: {
                                    type: "number",
                                    label: "Maximum objects to fetch",
                                    ref: "maxObjects",
                                    defaultValue: 50,
                                    min: 1,
                                    max: 100
                                },
                                showMetadata: {
                                    type: "boolean",
                                    label: "Show object metadata",
                                    ref: "showMetadata",
                                    defaultValue: true
                                },
                                showData: {
                                    type: "boolean",
                                    label: "Show object data preview",
                                    ref: "showData",
                                    defaultValue: true
                                }
                            }
                        }
                    }
                }
            }
        },

        support: {
            snapshot: false,
            export: false,
            exportData: false
        },

        paint: function($element, layout) {
            const self = this;
            const app = qlik.currApp(this);
            
            // Initialize the extension
            $element.html(template);
            
            // Initialize data fetcher
            this.initializeDataFetcher(app, layout, $element);
            
            return qlik.Promise.resolve();
        },

        initializeDataFetcher: function(app, layout, $element) {
            const self = this;
            
            // Clear previous content
            $element.find('#object-list').empty();
            $element.find('#status').text('Discovering objects...');
            
            // Start object discovery and data fetching
            this.discoverAndFetchObjects(app, layout, $element)
                .then(function(results) {
                    self.renderResults(results, layout, $element);
                    self.setupAutoRefresh(app, layout, $element);
                })
                .catch(function(error) {
                    console.error('Error fetching object data:', error);
                    $element.find('#status').text('Error: ' + error.message);
                    $element.find('#error-details').text(JSON.stringify(error, null, 2));
                });
        },

        discoverAndFetchObjects: function(app, layout, $element) {
            const self = this;
            const maxObjects = layout.maxObjects || 50;
            
            return new Promise(function(resolve, reject) {
                const results = {
                    objects: [],
                    errors: [],
                    totalCount: 0
                };

                // Get all objects in the application
                app.getList('sheet', function(sheetList) {
                    const sheetPromises = sheetList.qAppObjectList.qItems.slice(0, maxObjects).map(function(sheet) {
                        return self.processSheet(app, sheet, layout);
                    });

                    Promise.all(sheetPromises)
                        .then(function(sheetResults) {
                            // Flatten results from all sheets
                            sheetResults.forEach(function(sheetResult) {
                                results.objects = results.objects.concat(sheetResult.objects);
                                results.errors = results.errors.concat(sheetResult.errors);
                            });

                            // Also get standalone objects
                            return self.getStandaloneObjects(app, layout);
                        })
                        .then(function(standaloneResults) {
                            results.objects = results.objects.concat(standaloneResults.objects);
                            results.errors = results.errors.concat(standaloneResults.errors);
                            results.totalCount = results.objects.length;
                            
                            resolve(results);
                        })
                        .catch(reject);
                });
            });
        },

        processSheet: function(app, sheet, layout) {
            const self = this;
            
            return new Promise(function(resolve) {
                const sheetResult = {
                    objects: [],
                    errors: []
                };

                app.getObject(sheet.qInfo.qId)
                    .then(function(sheetObj) {
                        return sheetObj.getLayout();
                    })
                    .then(function(sheetLayout) {
                        const childPromises = sheetLayout.cells ? sheetLayout.cells.map(function(cell) {
                            return self.fetchObjectData(app, cell.name, layout);
                        }) : [];

                        return Promise.all(childPromises);
                    })
                    .then(function(childResults) {
                        childResults.forEach(function(result) {
                            if (result.success) {
                                sheetResult.objects.push(result.data);
                            } else {
                                sheetResult.errors.push(result.error);
                            }
                        });
                        resolve(sheetResult);
                    })
                    .catch(function(error) {
                        sheetResult.errors.push({
                            objectId: sheet.qInfo.qId,
                            message: 'Failed to process sheet: ' + error.message
                        });
                        resolve(sheetResult);
                    });
            });
        },

        getStandaloneObjects: function(app, layout) {
            const self = this;
            
            return new Promise(function(resolve) {
                const result = {
                    objects: [],
                    errors: []
                };

                // Get various object types
                const objectTypes = ['chart', 'table', 'filterpane', 'listbox', 'textimage'];
                const typePromises = objectTypes.map(function(type) {
                    return new Promise(function(typeResolve) {
                        app.getList(type, function(list) {
                            if (list && list.qAppObjectList && list.qAppObjectList.qItems) {
                                const objectPromises = list.qAppObjectList.qItems.map(function(item) {
                                    return self.fetchObjectData(app, item.qInfo.qId, layout);
                                });

                                Promise.all(objectPromises)
                                    .then(function(objectResults) {
                                        objectResults.forEach(function(objectResult) {
                                            if (objectResult.success) {
                                                result.objects.push(objectResult.data);
                                            } else {
                                                result.errors.push(objectResult.error);
                                            }
                                        });
                                        typeResolve();
                                    })
                                    .catch(function() {
                                        typeResolve();
                                    });
                            } else {
                                typeResolve();
                            }
                        });
                    });
                });

                Promise.all(typePromises).then(function() {
                    resolve(result);
                });
            });
        },

        fetchObjectData: function(app, objectId, layout) {
            const self = this;
            
            return new Promise(function(resolve) {
                app.getObject(objectId)
                    .then(function(obj) {
                        return obj.getLayout();
                    })
                    .then(function(objLayout) {
                        const objectData = {
                            id: objectId,
                            title: objLayout.title || objLayout.qInfo.qId,
                            type: objLayout.qInfo.qType,
                            metadata: {
                                qId: objLayout.qInfo.qId,
                                qType: objLayout.qInfo.qType,
                                visualization: objLayout.visualization || 'unknown'
                            },
                            data: null,
                            dataStructure: null,
                            timestamp: new Date().toISOString()
                        };

                        // Extract data based on object type
                        if (objLayout.qHyperCube) {
                            objectData.dataStructure = 'HyperCube';
                            objectData.data = self.extractHyperCubeData(objLayout.qHyperCube, layout);
                        } else if (objLayout.qListObject) {
                            objectData.dataStructure = 'ListObject';
                            objectData.data = self.extractListObjectData(objLayout.qListObject, layout);
                        } else if (objLayout.qPivotTable) {
                            objectData.dataStructure = 'PivotTable';
                            objectData.data = self.extractPivotTableData(objLayout.qPivotTable, layout);
                        } else {
                            objectData.dataStructure = 'Other';
                            objectData.data = {
                                message: 'Data structure not supported for automatic extraction',
                                rawLayout: layout.showMetadata ? objLayout : null
                            };
                        }

                        resolve({
                            success: true,
                            data: objectData
                        });
                    })
                    .catch(function(error) {
                        resolve({
                            success: false,
                            error: {
                                objectId: objectId,
                                message: error.message || 'Failed to fetch object data',
                                details: error
                            }
                        });
                    });
            });
        },

        extractHyperCubeData: function(hyperCube, layout) {
            const data = {
                dimensions: hyperCube.qDimensionInfo ? hyperCube.qDimensionInfo.map(function(dim) {
                    return {
                        label: dim.qFallbackTitle,
                        field: dim.qGroupFieldDefs ? dim.qGroupFieldDefs[0] : 'unknown'
                    };
                }) : [],
                measures: hyperCube.qMeasureInfo ? hyperCube.qMeasureInfo.map(function(measure) {
                    return {
                        label: measure.qFallbackTitle,
                        expression: measure.qDef
                    };
                }) : [],
                rowCount: hyperCube.qSize ? hyperCube.qSize.qcy : 0,
                columnCount: hyperCube.qSize ? hyperCube.qSize.qcx : 0,
                dataPages: []
            };

            if (layout.showData && hyperCube.qDataPages && hyperCube.qDataPages.length > 0) {
                data.dataPages = hyperCube.qDataPages.map(function(page) {
                    return {
                        rows: page.qMatrix ? page.qMatrix.slice(0, 10) : [], // Limit to first 10 rows
                        area: page.qArea
                    };
                });
            }

            return data;
        },

        extractListObjectData: function(listObject, layout) {
            const data = {
                field: listObject.qDimensionInfo ? listObject.qDimensionInfo.qFallbackTitle : 'unknown',
                valueCount: listObject.qSize ? listObject.qSize.qcy : 0,
                values: []
            };

            if (layout.showData && listObject.qDataPages && listObject.qDataPages.length > 0) {
                data.values = listObject.qDataPages[0].qMatrix ? 
                    listObject.qDataPages[0].qMatrix.slice(0, 20).map(function(row) {
                        return {
                            text: row[0].qText,
                            value: row[0].qNum,
                            state: row[0].qState
                        };
                    }) : [];
            }

            return data;
        },

        extractPivotTableData: function(pivotTable, layout) {
            const data = {
                dimensions: pivotTable.qDimensionInfo ? pivotTable.qDimensionInfo.map(function(dim) {
                    return {
                        label: dim.qFallbackTitle,
                        field: dim.qGroupFieldDefs ? dim.qGroupFieldDefs[0] : 'unknown'
                    };
                }) : [],
                measures: pivotTable.qMeasureInfo ? pivotTable.qMeasureInfo.map(function(measure) {
                    return {
                        label: measure.qFallbackTitle,
                        expression: measure.qDef
                    };
                }) : [],
                rowCount: pivotTable.qSize ? pivotTable.qSize.qcy : 0,
                columnCount: pivotTable.qSize ? pivotTable.qSize.qcx : 0,
                dataPages: []
            };

            if (layout.showData && pivotTable.qDataPages && pivotTable.qDataPages.length > 0) {
                data.dataPages = pivotTable.qDataPages.map(function(page) {
                    return {
                        rows: page.qData ? page.qData.slice(0, 10) : [],
                        area: page.qArea
                    };
                });
            }

            return data;
        },

        renderResults: function(results, layout, $element) {
            const $objectList = $element.find('#object-list');
            const $status = $element.find('#status');
            const $summary = $element.find('#summary');

            // Update status
            $status.text(`Successfully fetched data from ${results.objects.length} objects`);
            
            // Update summary
            $summary.html(`
                <div class="summary-stats">
                    <span class="stat"><strong>Total Objects:</strong> ${results.objects.length}</span>
                    <span class="stat"><strong>Errors:</strong> ${results.errors.length}</span>
                    <span class="stat"><strong>Last Updated:</strong> ${new Date().toLocaleTimeString()}</span>
                </div>
            `);

            // Clear previous results
            $objectList.empty();

            // Render objects
            results.objects.forEach(function(obj) {
                const $objectItem = $(`
                    <div class="object-item">
                        <div class="object-header">
                            <h3>${obj.title}</h3>
                            <span class="object-type">${obj.type}</span>
                        </div>
                        <div class="object-details">
                            ${layout.showMetadata ? `
                                <div class="metadata">
                                    <h4>Metadata</h4>
                                    <ul>
                                        <li><strong>ID:</strong> ${obj.id}</li>
                                        <li><strong>Type:</strong> ${obj.type}</li>
                                        <li><strong>Data Structure:</strong> ${obj.dataStructure}</li>
                                        <li><strong>Timestamp:</strong> ${obj.timestamp}</li>
                                    </ul>
                                </div>
                            ` : ''}
                            ${layout.showData ? `
                                <div class="data-preview">
                                    <h4>Data Preview</h4>
                                    <pre>${JSON.stringify(obj.data, null, 2)}</pre>
                                </div>
                            ` : ''}
                        </div>
                    </div>
                `);
                $objectList.append($objectItem);
            });

            // Render errors if any
            if (results.errors.length > 0) {
                const $errorSection = $(`
                    <div class="error-section">
                        <h3>Errors (${results.errors.length})</h3>
                        <div class="error-list"></div>
                    </div>
                `);
                
                results.errors.forEach(function(error) {
                    $errorSection.find('.error-list').append(`
                        <div class="error-item">
                            <strong>Object ID:</strong> ${error.objectId}<br>
                            <strong>Error:</strong> ${error.message}
                        </div>
                    `);
                });
                
                $objectList.append($errorSection);
            }
        },

        setupAutoRefresh: function(app, layout, $element) {
            const self = this;
            const refreshInterval = (layout.refreshInterval || 30) * 1000; // Convert to milliseconds

            // Clear any existing interval
            if (this.refreshIntervalId) {
                clearInterval(this.refreshIntervalId);
            }

            // Set up new interval
            this.refreshIntervalId = setInterval(function() {
                self.initializeDataFetcher(app, layout, $element);
            }, refreshInterval);
        },

        beforeDestroy: function() {
            // Clean up interval when extension is destroyed
            if (this.refreshIntervalId) {
                clearInterval(this.refreshIntervalId);
            }
        }
    };
});
